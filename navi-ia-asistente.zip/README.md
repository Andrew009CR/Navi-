# navi IA asistente (PWA)
Asistente IA con modo offline, identificación de imágenes, voz y chat local.

## Logo personalizado
En **Ajustes** puedes subir tu logo. Se guarda en tu dispositivo (localStorage) y se aplica al header y favicon inmediatamente.

## Instalación rápida (Netlify)
1. Descomprime el ZIP.
2. Entra a https://app.netlify.com/drop y arrastra la carpeta `navi-ia-asistente`.
3. Abre la URL resultante en tu Android (Chrome/Edge) y elige **Añadir a pantalla de inicio**.
4. Entra una vez con Internet para cachear modelos. Luego podrás usar sin conexión.

## Notas
- Web Speech API puede no estar disponible en todos los navegadores.
- Vosk ES (~50MB) se descarga una vez y queda cacheado (si CORS lo permite). Si no, podrás grabar notas offline igualmente.
