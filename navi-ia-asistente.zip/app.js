
// navi IA asistente — App JS

if ('serviceWorker' in navigator) {
  addEventListener('load', () => {
    navigator.serviceWorker.register('service-worker.js').catch(()=>{});
  });
}

const state = {
  offline: false,
  voskReady: false,
  vosk: null,
  recognizer: null,
  mediaRecorder: null,
  chunks: [],
  mobilenetModel: null,
  settings: {
    endpoint: localStorage.getItem('llm.endpoint') || '',
    key: localStorage.getItem('llm.key') || '',
    logo: localStorage.getItem('app.logo') || '' // data URL si el usuario sube un logo
  }
};

const $ = (sel) => document.querySelector(sel);
const chatLog = $('#chatLog');
const logoImg = $('#appLogo');
const favicon = $('#favicon');

function applyLogo() {
  if (state.settings.logo) {
    logoImg.src = state.settings.logo;
    if (favicon) favicon.href = state.settings.logo;
  }
}
applyLogo();

function addMsg(who, text) {
  const div = document.createElement('div');
  div.className = `msg ${who}`;
  div.textContent = text;
  chatLog.appendChild(div);
  chatLog.scrollTop = chatLog.scrollHeight;
}

const offlineToggle = $('#offlineToggle');
offlineToggle.addEventListener('change', () => {
  state.offline = offlineToggle.checked;
  document.body.classList.toggle('offline', state.offline);
  addMsg('bot', state.offline ? 'Modo offline ACTIVADO.' : 'Modo offline DESACTIVADO.');
});

const chatText = $('#chatText');
$('#sendBtn').addEventListener('click', async () => {
  const text = chatText.value.trim();
  if (!text) return;
  addMsg('me', text);
  chatText.value = '';

  if (!state.offline && state.settings.endpoint) {
    try {
      const res = await fetch(state.settings.endpoint, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', ...(state.settings.key ? { Authorization: `Bearer ${state.settings.key}` } : {}) },
        body: JSON.stringify({ prompt: text })
      });
      const data = await res.json();
      const reply = data.reply || JSON.stringify(data).slice(0, 500);
      return addMsg('bot', reply);
    } catch (e) {
      addMsg('bot', 'No pude contactar el endpoint. Respondo localmente.');
    }
  }

  const t = text.toLowerCase();
  let reply = 'Puedo identificar imágenes, tomar notas de voz y funcionar sin Internet.';
  if (t.includes('hola')) reply = '¡Hola! Soy navi IA asistente. ¿Qué hacemos hoy?';
  if (t.includes('offline')) reply = 'En modo offline: clasificación de imágenes (MobileNet), grabación de voz y transcripción con Vosk (opcional).';
  if (t.includes('imagen')) reply = 'Sube una imagen y presiona “Identificar”.';
  if (t.includes('voz')) reply = 'Pulsa “Empezar” para dictado o grabación. Online uso Web Speech; offline puedes usar Vosk.';
  addMsg('bot', reply);
});

$('#saveSettings').addEventListener('click', () => {
  localStorage.setItem('llm.endpoint', $('#llmEndpoint').value.trim());
  localStorage.setItem('llm.key', $('#llmKey').value.trim());
  localStorage.setItem('app.logo', state.settings.logo || '');
  state.settings.endpoint = localStorage.getItem('llm.endpoint');
  state.settings.key = localStorage.getItem('llm.key');
  addMsg('bot', 'Ajustes guardados.');
});

$('#llmEndpoint').value = state.settings.endpoint;
$('#llmKey').value = state.settings.key;

$('#logoInput').addEventListener('change', () => {
  const f = $('#logoInput').files?.[0];
  if (!f) return;
  const reader = new FileReader();
  reader.onload = () => {
    state.settings.logo = reader.result;
    applyLogo();
    addMsg('bot', 'Logo aplicado. Recarga para mantenerlo visible desde el inicio.');
  };
  reader.readAsDataURL(f);
});
$('#resetLogo').addEventListener('click', () => {
  state.settings.logo = '';
  localStorage.removeItem('app.logo');
  logoImg.src = 'icons/icon-96.png';
  if (favicon) favicon.href = 'icons/icon-192.png';
  addMsg('bot', 'Logo restaurado al predeterminado.');
});

// Voz
const voiceStatus = $('#voiceStatus');
const transcript = $('#transcript');
const notesList = $('#voiceNotes');
let speechRec = null;

function useWebSpeech() {
  const Rec = window.SpeechRecognition || window.webkitSpeechRecognition;
  if (!Rec) return null;
  const r = new Rec();
  r.lang = 'es-MX';
  r.continuous = true;
  r.interimResults = true;
  r.onresult = (ev) => {
    let txt='';
    for (let i=ev.resultIndex;i<ev.results.length;i++){
      txt += ev.results[i][0].transcript + (ev.results[i].isFinal?'\n':'');
    }
    transcript.textContent = txt;
  };
  r.onstart = () => voiceStatus.textContent = 'Escuchando (Web Speech)...';
  r.onend = () => voiceStatus.textContent = 'Listo';
  r.onerror = (e)=> voiceStatus.textContent = 'Error voz: ' + e.error;
  return r;
}

async function ensureVosk() {
  if (state.voskReady) return true;
  try {
    voiceStatus.textContent = 'Cargando Vosk...';
    await new Promise((resolve, reject) => {
      const s = document.createElement('script');
      s.src = window.VOSK_CDN;
      s.onload = resolve; s.onerror = reject;
      document.head.appendChild(s);
    });
    const { Vosk } = window;
    const model = new Vosk.Model(window.VOSK_ES_MODEL);
    await model.init();
    const recognizer = new model.Recognizer({ sampleRate: 48000 });
    state.vosk = { model, recognizer };
    state.voskReady = true;
    voiceStatus.textContent = 'Vosk listo.';
    return true;
  } catch (e) {
    voiceStatus.textContent = 'No se pudo cargar Vosk (CORS).';
    return false;
  }
}

async function startVoice() {
  if (state.offline) {
    const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
    state.mediaRecorder = new MediaRecorder(stream);
    state.chunks = [];
    state.mediaRecorder.ondataavailable = (e)=> state.chunks.push(e.data);
    state.mediaRecorder.onstop = async ()=>{
      const blob = new Blob(state.chunks, { type:'audio/webm' });
      const url = URL.createObjectURL(blob);
      const li = document.createElement('li');
      const audio = document.createElement('audio');
      audio.controls = true; audio.src = url;
      const del = document.createElement('button');
      del.textContent = '🗑'; del.className = 'btn btn-ghost'; del.onclick = ()=> li.remove();
      li.appendChild(audio); li.appendChild(del); notesList.prepend(li);

      if (state.voskReady && state.vosk && state.vosk.recognizer) {
        voiceStatus.textContent = 'Transcribiendo (offline)...';
        try {
          const buf = await blob.arrayBuffer();
          const pcm = new Float32Array(buf); // placeholder
          state.vosk.recognizer.acceptWaveform(pcm);
          const res = state.vosk.recognizer.finalResult();
          transcript.textContent = (res && res.text) ? res.text : '(sin texto)';
          voiceStatus.textContent = 'Listo';
        } catch(e){ voiceStatus.textContent = 'No se pudo transcribir offline.'; }
      }
    };
    state.mediaRecorder.start();
    voiceStatus.textContent = 'Grabando (offline)…';
  } else {
    speechRec = useWebSpeech();
    if (!speechRec){ voiceStatus.textContent = 'Navegador sin soporte Web Speech.'; return; }
    speechRec.start();
  }
}
function stopVoice(){
  if (state.offline && state.mediaRecorder){ state.mediaRecorder.stop(); }
  if (!state.offline && speechRec){ try{ speechRec.stop(); }catch{} }
}
$('#startVoice').addEventListener('click', startVoice);
$('#stopVoice').addEventListener('click', stopVoice);
$('#downloadVosk').addEventListener('click', ensureVosk);

// Imágenes (MobileNet)
const imgEl = $('#preview');
const imageInput = $('#imageInput');
const resultsEl = $('#results');

imageInput.addEventListener('change', () => {
  const f = imageInput.files?.[0];
  if (!f) return;
  const url = URL.createObjectURL(f);
  imgEl.src = url;
  resultsEl.textContent = '';
});

async function loadMobileNet() {
  if (state.mobilenetModel) return state.mobilenetModel;
  state.mobilenetModel = await mobilenet.load();
  return state.mobilenetModel;
}
async function classify() {
  if (!imgEl.src) return alert('Primero selecciona una imagen.');
  try {
    const model = await loadMobileNet();
    const preds = await model.classify(imgEl);
    resultsEl.innerHTML = preds.map(p=>`<div>• ${p.className} — ${(p.probability*100).toFixed(1)}%</div>`).join('');
  } catch(e){
    resultsEl.textContent = 'No pude identificar la imagen (¿primera carga sin Internet?).';
  }
}
document.querySelector('#classifyBtn').addEventListener('click', classify);
