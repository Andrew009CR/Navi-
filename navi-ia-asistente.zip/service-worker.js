
const CACHE_NAME = 'navi-ia-asistente-v1';
const CORE_ASSETS = [
  '/',
  '/index.html',
  '/styles.css',
  '/app.js',
  '/manifest.webmanifest',
  '/icons/icon-192.png',
  '/icons/icon-512.png',
];
const CDN_ALLOWLIST = [
  'https://cdn.jsdelivr.net/',
  'https://unpkg.com/',
  'https://alphacephei.com/'
];
self.addEventListener('install', (e) => {
  e.waitUntil(caches.open(CACHE_NAME).then(cache => cache.addAll(CORE_ASSETS)));
  self.skipWaiting();
});
self.addEventListener('activate', (e) => {
  e.waitUntil(caches.keys().then(keys => Promise.all(keys.filter(k=>k!==CACHE_NAME).map(k=>caches.delete(k)))));
  self.clients.claim();
});
self.addEventListener('fetch', (e) => {
  const url = e.request.url;
  if (CDN_ALLOWLIST.some(origin => url.startsWith(origin))) {
    e.respondWith((async () => {
      const cache = await caches.open(CACHE_NAME);
      const cached = await cache.match(e.request);
      const fetchPromise = fetch(e.request).then(response => {
        try { cache.put(e.request, response.clone()); } catch {}
        return response;
      }).catch(()=>cached);
      return cached || fetchPromise;
    })());
    return;
  }
  e.respondWith((async () => {
    const cache = await caches.open(CACHE_NAME);
    try {
      const fresh = await fetch(e.request);
      try { cache.put(e.request, fresh.clone()); } catch {}
      return fresh;
    } catch (err) {
      const cached = await cache.match(e.request);
      if (cached) return cached;
      if (e.request.mode === 'navigate') return caches.match('/');
      throw err;
    }
  })());
});
